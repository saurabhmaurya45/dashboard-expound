const EmptyState = () => {

  return (
    <div className="flex items-center justify-center text-gray-600 text-2xl">
      Hang tight! We're preparing something awesome for you.
    </div>
  )
}

export default EmptyState
